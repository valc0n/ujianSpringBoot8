package com.juaracoding.model;

public interface KeberangkatanCustomModel {
	
	long getId();
	String getDeskripsi();
	String getTanggal();
	String getNama_perusahaan();
	String getKelas();
	int getHarga();
}
