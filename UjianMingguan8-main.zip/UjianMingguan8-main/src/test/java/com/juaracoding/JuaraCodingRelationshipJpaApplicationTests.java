package com.juaracoding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuaraCodingRelationshipJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
